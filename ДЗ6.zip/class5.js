//Переменные для окна входа
let dialog = document.getElementById("dialog")
let email = document.getElementById("email")
let password = document.getElementById("password")
let btn = document.getElementById("btn")
let err = document.getElementById("error")
let sigin_up = document.getElementById("sigin_up")
//Переменные для окна бызы данных
let acc = document.getElementById("acc")
let user_name = document.getElementById("user_name")
let user_email = document.getElementById("user_email")
let user_contact = document.getElementById("user_contact")
let btn_exit = document.getElementById("btn_exit")
// Переменные для окна регистрации
let registration = document.getElementById("registration")
let email_reg = document.getElementById("email_reg")
let name_reg = document.getElementById("name_reg")
let contact_reg = document.getElementById("contact_reg")
let password_reg = document.getElementById("password_reg")
let btn_reg = document.getElementById("btn_reg")
let sing_in = document.getElementById("sing_in")
let err_reg = document.getElementById("error_reg")
//Оптимизация кода
const changePage = (closePage, openPage) => {
    closePage.classList.remove(`${closePage.id}_visible`)
    closePage.classList.add(`${closePage.id}_hide`)
    openPage.classList.remove(`${openPage.id}_hide`)
    openPage.classList.add(`${openPage.id}_visible`)
}
const allClean = () => {
    email.value = "";
    password.value = "";
    name_reg.value = "";
    email_reg.value = "";
    contact_reg.value = "";
    password_reg.value = "";
    err_reg.textContent = "";
    err.textContent = ""
}

//Логика в окне входа
const users = [
    {name: "Nikita", 
    email: "nick@mail.ru", 
    contact: "8-913-470-43-56", 
    password: "1234"},

    {name: "Dima", 
    email: "dima@mail.ru", 
    contact: "7-926-590-93-12", 
    password: "4321"},

    {name: "Stas", 
    email: "stas@mail.ru", 
    contact: "3-123-456-78-90", 
    password: "1517"},

    {name: "Pasha", 
    email: "pasha@mail.ru", 
    contact: "6-914-741-15-83", 
    password: "1058"},
]

const checkPass = () => {
    for (let i = 0; i < users.length; i++) {
        if (password.value === users[i].password && 
            email.value === users[i].email) {
                changePage(dialog, acc)
                user_name.textContent = users[i].name;
                user_email.textContent = users[i].email;
                user_contact.textContent = users[i].contact;
                err.textContent = "";
        } else {
            err.textContent = "Неверные данные"
        }
    }
};
btn.addEventListener("click", checkPass)

const navigateSign_up = () => {
    changePage(dialog, registration)
    allClean()
}
sigin_up.addEventListener("click", navigateSign_up)

//Логика в личном кабинете
const goBack = () => {
    changePage(acc, dialog)
    //err.textContent = ""
    allClean()
}
btn_exit.addEventListener("click", goBack)

// Логика в окне регистрации
const navigateSingn_in = () => {
    changePage(registration, dialog)
    allClean()
}
sing_in.addEventListener("click", navigateSingn_in)

const addDataPerson = () => {
    if(name_reg.value && 
        contact_reg.value && 
        password_reg.value.length >= 4 &&
        email_reg.value.includes("@")
    )
    {
    let newPerson = {
        name: name_reg.value, 
        email: email_reg.value,
        contact: contact_reg.value, 
        password: password_reg.value,
    };
    users.push(newPerson)

    changePage(registration, acc)

    user_name.textContent = name_reg.value;
    user_email.textContent = email_reg.value;
    user_contact.textContent = contact_reg.value;
    allClean() } 
    else if (password_reg.value.length < 4) { 
    err_reg.textContent = "Пароль должен быть не меньше 4 символов" } 
    else if (email_reg.value.includes("@") === false) {
    err_reg.textContent = "В почте должен быть символ @"} 
    else {
    err_reg.textContent = "Введены не все данные" }
}
btn_reg.addEventListener("click", addDataPerson)